import Sectiontwo from '../assets/images/sectiontwo.jpg'

function Sectiontwo(){
    return(
        <div className = "container"> 
            <div className="leftside">
            <img src="{sectiontwo}" alt='Feature-Img'/>
        </div>
         <div myclass="rightside">
            <h1>Loading</h1>
            </div>

        </div>
    )
};

export default Sectiontwo;